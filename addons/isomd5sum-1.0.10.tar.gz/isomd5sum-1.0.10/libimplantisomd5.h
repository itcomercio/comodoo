#ifndef __LIBIMPLANTISOMD5_H__
#define __LIBIMPLANTISOMD5_H__
int implantISOFile(char *iso, int supported, int forceit, int quiet, char **errstr);
#endif

